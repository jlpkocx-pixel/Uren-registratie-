# Urenkalender: APK laten bouwen (zonder te programmeren)

Je hebt alleen een gratis GitHub-account en een computer nodig (op de telefoon kan het ook, maar op een computer gaat het makkelijker).

## 1. Account en opslagplaats
1. Ga naar github.com en maak een gratis account.
2. Klik rechtsboven op **+** en kies **New repository**. Naam: `urenkalender`. Kies **Private**. Klik **Create repository**.

## 2. Bestanden uploaden
1. Pak de zip uit op je computer.
2. Klik in je nieuwe opslagplaats op **uploading an existing file**.
3. Sleep ALLE bestanden en mappen uit de uitgepakte map naar het venster (app, gradle.properties, build.gradle.kts, settings.gradle.kts, urenkalender.keystore, enzovoort). Wacht tot alles is geladen en klik **Commit changes**.

Let op: de verborgen map `.github` (met de bouwopdracht) wordt vaak niet meegesleept. Controleer na het uploaden of je in de lijst een map `.github` ziet. Zo niet:
1. Klik **Add file > Create new file**.
2. Typ als naam: `.github/workflows/build-apk.yml` (de schuine strepen maken de mappen vanzelf).
3. Plak de inhoud van het losse bestand `build-apk.yml` uit de zip en klik **Commit changes**.

## 3. APK laten bouwen
1. Klik bovenin op het tabblad **Actions**. (Vraagt hij om workflows aan te zetten, bevestig dat.)
2. Je ziet een bouwronde draaien ("Bouw Urenkalender APK"). Het duurt ongeveer 5 tot 10 minuten. Een groen vinkje betekent klaar.
3. Klik op de ronde en scroll naar **Artifacts**. Download **Urenkalender-APK** (een zip met `app-release.apk`).
4. Staat er een rood kruis? Open de ronde, kopieer de foutmelding en stuur die naar mij. Ik pas het aan.

## 4. Installeren op je telefoon
1. Zet het bestand `app-release.apk` op je telefoon (via Drive, mail of kabel).
2. Open het bestand. Android vraagt om "Onbekende apps installeren" toe te staan voor die app (Bestanden of Chrome). Zet dat aan en installeer.
3. Open Urenkalender, ga naar **Instellingen > Werklocaties** en tik op **Locatietoegang instellen**.
   - Kies eerst "Tijdens gebruik van de app" of "Precieze locatie".
   - Kies daarna bij de app-instellingen voor Locatie: **Altijd toestaan**.
4. Voeg je werklocatie toe (coördinaten of Google Maps-link).
5. Zet bij de batterij-instellingen van de app het energiebesparen op "Onbeperkt" (Instellingen > Apps > Urenkalender > Batterij). Anders kan sommige telefoons de locatiemeldingen uitstellen.

## Goed om te weten
- Alles blijft op je telefoon. Er is geen login en er wordt niets verstuurd.
- Bijwerken: upload later een nieuwe versie van de bestanden naar dezelfde opslagplaats, bouw opnieuw en installeer de nieuwe APK gewoon over de oude heen. Je gegevens blijven dan staan, omdat de app met dezelfde sleutel (urenkalender.keystore) wordt getekend. Verwijder de app niet eerst, dan ben je je gegevens kwijt.
- Aankomst en vertrek worden door Android geregistreerd, ook als de app dicht is. De tijden verschijnen in je kalender zodra je de app opent. De correctie, het vastzetten op je rooster en het afronden worden dan toegepast.
- Rapporten (Excel, PDF, CSV) komen in de map **Downloads** op je telefoon.
- De sleutel in deze map is bedoeld voor eigen gebruik. Je kunt de app niet in de Play Store zetten met deze sleutel, en collega's installeren dezelfde APK gewoon via hun eigen telefoon.
- Deze code is hier niet gecompileerd of op een echte telefoon getest. Kleine bouwfouten of verschillen per telefoonmerk zijn mogelijk. Stuur een foutmelding of beschrijving en ik los het op.
