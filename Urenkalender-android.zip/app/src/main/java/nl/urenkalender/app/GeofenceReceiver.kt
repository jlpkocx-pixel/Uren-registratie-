package nl.urenkalender.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val ev = GeofencingEvent.fromIntent(intent) ?: return
        if (ev.hasError()) return
        val now = System.currentTimeMillis()
        for (g in ev.triggeringGeofences ?: emptyList()) {
            val parts = g.requestId.split("|", limit = 2)
            if (parts.size != 2) continue
            if (ev.geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER && parts[0] == "in")
                GeoStore.addEvent(context, "enter", parts[1], now)
            if (ev.geofenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT && parts[0] == "out")
                GeoStore.addEvent(context, "exit", parts[1], now)
        }
        MainActivity.notifyGeo()
    }
}
