package nl.urenkalender.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import java.lang.ref.WeakReference

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    private val askFine = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        afterPermissionStep()
    }
    private val askBackground = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        afterPermissionStep()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) { }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onResume() {
        super.onResume()
        current = WeakReference(this)
        try { Geo.register(this) } catch (e: Exception) { }
        js("window.__onPerm && window.__onPerm(); window.__onGeo && window.__onGeo();")
    }

    override fun onDestroy() {
        if (current?.get() === this) current = null
        super.onDestroy()
    }

    private fun js(code: String) {
        Handler(Looper.getMainLooper()).post { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }

    private fun startPermissionFlow() {
        if (!Geo.hasForeground(this)) {
            AlertDialog.Builder(this)
                .setTitle("Locatie")
                .setMessage("De app gebruikt je locatie alleen om te zien wanneer je op je werklocatie aankomt of vertrekt. Er wordt niets verstuurd; alles blijft op je telefoon.")
                .setPositiveButton("Doorgaan") { _, _ ->
                    askFine.launch(arrayOf(
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ))
                }
                .setNegativeButton("Annuleren", null).show()
        } else if (!Geo.hasBackground(this)) {
            AlertDialog.Builder(this)
                .setTitle("Altijd toestaan")
                .setMessage("Kies op het volgende scherm bij Locatie de optie \"Altijd toestaan\". Anders werkt de automatische registratie niet als de app dicht is.")
                .setPositiveButton("Doorgaan") { _, _ ->
                    if (android.os.Build.VERSION.SDK_INT >= 30) {
                        // Vanaf Android 11 kiest de gebruiker dit in de instellingen.
                        try {
                            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:$packageName")))
                        } catch (e: Exception) { }
                    } else {
                        askBackground.launch(android.Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    }
                }
                .setNegativeButton("Annuleren", null).show()
        }
    }

    private fun afterPermissionStep() {
        try { Geo.register(this) } catch (e: Exception) { }
        js("window.__onPerm && window.__onPerm();")
        if (Geo.hasForeground(this) && !Geo.hasBackground(this)) startPermissionFlow()
    }

    inner class Bridge {
        @JavascriptInterface
        fun setLocations(json: String) {
            GeoStore.saveLocations(this@MainActivity, json)
            try { Geo.register(this@MainActivity) } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun pullEvents(): String = GeoStore.takeEvents(this@MainActivity)

        @JavascriptInterface
        fun permStatus(): String = Geo.status(this@MainActivity)

        @JavascriptInterface
        fun requestPermissions() {
            runOnUiThread { startPermissionFlow() }
        }

        @JavascriptInterface
        fun saveFile(name: String, base64: String): Boolean {
            return try {
                val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                val mime = when (safe.substringAfterLast('.', "").lowercase()) {
                    "pdf" -> "application/pdf"
                    "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    "csv" -> "text/csv"
                    else -> "application/octet-stream"
                }
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safe)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                contentResolver.openOutputStream(uri)?.use { it.write(Base64.decode(base64, Base64.DEFAULT)) }
                    ?: return false
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Opgeslagen in Downloads: $safe", Toast.LENGTH_LONG).show()
                }
                true
            } catch (e: Exception) {
                false
            }
        }
    }

    companion object {
        private var current: WeakReference<MainActivity>? = null
        fun notifyGeo() {
            current?.get()?.js("window.__onGeo && window.__onGeo();")
        }
    }
}
