package nl.urenkalender.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

object Geo {
    fun hasForeground(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackground(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun status(c: Context) = when {
        hasForeground(c) && hasBackground(c) -> "ok"
        hasForeground(c) -> "foreground"
        else -> "none"
    }

    private fun pending(c: Context): PendingIntent {
        val i = Intent(c, GeofenceReceiver::class.java)
        return PendingIntent.getBroadcast(
            c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
    }

    /**
     * Per werklocatie twee geofences:
     *  - "in|id"  met de aankomststraal  -> alleen ENTER telt
     *  - "out|id" met de vertrekstraal   -> alleen EXIT telt
     * Tussen die twee stralen gebeurt niets, dat voorkomt valse vertrektijden.
     * Android raadt een straal van minimaal ongeveer 100 m aan.
     */
    @SuppressLint("MissingPermission")
    fun register(c: Context) {
        val client = LocationServices.getGeofencingClient(c.applicationContext)
        val pi = pending(c)
        client.removeGeofences(pi)
        if (!hasForeground(c) || !hasBackground(c)) return
        val locs = GeoStore.locations(c)
        val list = ArrayList<Geofence>()
        for (n in 0 until locs.length()) {
            val l = locs.getJSONObject(n)
            val id = l.getString("id")
            val lat = l.getDouble("lat")
            val lon = l.getDouble("lon")
            val rin = l.optDouble("rin", 150.0).coerceAtLeast(100.0).toFloat()
            val rout = l.optDouble("rout", 250.0).coerceAtLeast(rin.toDouble() + 20).toFloat()
            list.add(
                Geofence.Builder().setRequestId("in|$id").setCircularRegion(lat, lon, rin)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER).build()
            )
            list.add(
                Geofence.Builder().setRequestId("out|$id").setCircularRegion(lat, lon, rout)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_EXIT).build()
            )
        }
        if (list.isEmpty()) return
        val req = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(list).build()
        client.addGeofences(req, pi)
    }
}
