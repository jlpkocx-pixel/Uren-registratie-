package nl.urenkalender.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Na een herstart (of app-update) zijn geofences weg; hier zetten we ze terug. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try { Geo.register(context) } catch (e: Exception) { }
    }
}
