package nl.urenkalender.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Bewaart de werklocaties en de nog niet verwerkte aankomst/vertrek-meldingen. */
object GeoStore {
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("geo", Context.MODE_PRIVATE)

    fun saveLocations(c: Context, json: String) {
        prefs(c).edit().putString("locations", json).apply()
    }

    fun locations(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString("locations", "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized
    fun addEvent(c: Context, type: String, locId: String, ts: Long) {
        val arr = try { JSONArray(prefs(c).getString("events", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("type", type).put("loc", locId).put("ts", ts))
        prefs(c).edit().putString("events", arr.toString()).apply()
    }

    /** Geeft alle meldingen terug en leegt de lijst. */
    @Synchronized
    fun takeEvents(c: Context): String {
        val s = prefs(c).getString("events", "[]") ?: "[]"
        prefs(c).edit().putString("events", "[]").apply()
        return s
    }
}
